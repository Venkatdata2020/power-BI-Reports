There are 5 files available in the student files.

1) Readme.txt file

This file explains the files in the course download.

2) DAX Workshop - Data Model.pbix

This file was created with the September 2020 version of Power BI Desktop. You will need the September 2020 version or later to open this PBIX file.

3) DAX Workshop Code Examples.txt

This file contains all the code examples for the Workshop. These code examples can be used to follow along during the class and to review the demos after! Not every example in this file will be reviewed or covered in the short duration of the recording.

4) DAX Workshop - Data Model_Completed.pbix

This is the completed version of the Power BI Desktop file with all completed examples. This file was created with the September 2020 version of Power BI Desktop.

5) DAX Workshop slides.pdf

This is a PDF version of the slides from the Workshop.